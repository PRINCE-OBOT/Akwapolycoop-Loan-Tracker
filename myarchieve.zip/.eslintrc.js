module.exports = {
  extends: [
    'airbnb-base',
    'prettier'
  ],
  env: {
    browser: true,
    node: true,
    es2021: true,
  },
  rules: {
    // custom overrides
  },
};